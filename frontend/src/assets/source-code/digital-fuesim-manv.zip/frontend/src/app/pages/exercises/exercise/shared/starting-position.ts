/**
 * The position of the Lake HPI in 14482 Potsdam, DE
 */
export const startingPosition = {
    x: 1461700,
    y: 6871500,
};
