import { Component } from '@angular/core';

@Component({
    selector: 'app-simulated-region-overview-behavior-answer-vehicle-requests',
    templateUrl:
        './simulated-region-overview-behavior-answer-vehicle-requests.component.html',
    styleUrls: [
        './simulated-region-overview-behavior-answer-vehicle-requests.component.scss',
    ],
})
export class SimulatedRegionOverviewBehaviorAnswerVehicleRequestsComponent {}
