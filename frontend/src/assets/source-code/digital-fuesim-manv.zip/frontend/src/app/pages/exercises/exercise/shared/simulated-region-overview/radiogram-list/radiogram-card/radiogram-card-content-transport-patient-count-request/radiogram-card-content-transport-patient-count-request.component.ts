import { Component } from '@angular/core';

@Component({
    selector: 'app-radiogram-card-content-transport-patient-count-request',
    templateUrl:
        './radiogram-card-content-transport-patient-count-request.component.html',
    styleUrls: [
        './radiogram-card-content-transport-patient-count-request.component.scss',
    ],
})
export class RadiogramCardContentTransportPatientCountRequestComponent {}
