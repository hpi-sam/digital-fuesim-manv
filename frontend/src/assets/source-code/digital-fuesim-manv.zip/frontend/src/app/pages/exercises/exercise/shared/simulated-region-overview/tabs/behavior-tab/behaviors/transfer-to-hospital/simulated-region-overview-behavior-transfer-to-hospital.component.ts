import { Component } from '@angular/core';

@Component({
    selector: 'app-simulated-region-overview-behavior-transfer-to-hospital',
    templateUrl:
        './simulated-region-overview-behavior-transfer-to-hospital.component.html',
    styleUrls: [
        './simulated-region-overview-behavior-transfer-to-hospital.component.scss',
    ],
})
export class SimulatedRegionOverviewBehaviorTransferToHospitalComponent {}
