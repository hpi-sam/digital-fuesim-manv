module.exports = {
    plugins: ['total-functions'],
    rules: {
        'total-functions/no-unsafe-readonly-mutable-assignment': 'error',
    },
};
