import { createNewDataSource } from './data-source';

export const dataSource = createNewDataSource();
