import type { ExerciseWrapper } from './exercise-wrapper';

export const exerciseMap = new Map<string, ExerciseWrapper>();
